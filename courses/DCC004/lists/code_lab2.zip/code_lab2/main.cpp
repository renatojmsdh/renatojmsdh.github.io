#include <iostream>
#include "src/sudoku.h"
#include "src/sudoku9.h"
#include "src/sudoku16.h"
#include "src/sudoku25.h"

int main() 
{
Sudoku *sudoku = new Sudoku[3];
sudoku[0] = Sudoku9();
sudoku[1] = Sudoku16();
sudoku[2] = Sudoku25();
return 0;
}

