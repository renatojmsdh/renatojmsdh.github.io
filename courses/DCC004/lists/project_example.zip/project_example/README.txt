# Para compilar usando o terminal
make

# Para executar
./main_axample

# Sai'da do programa
Ola DCC004

# Apagar objetos compilados e executa'veis
make clean
