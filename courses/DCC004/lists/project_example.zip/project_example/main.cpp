// Arquivo "main.cpp"
#include <iostream>
#include "src/ClassA.h"

int main()
{
    A a;
	return 0;
}
