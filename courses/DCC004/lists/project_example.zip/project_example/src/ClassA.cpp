// Arquivo "src/ClassA.cpp"
#include "ClassA.h"
A::A()    
{

std::cout<<"Ola DCC004"<<std::endl;

}

