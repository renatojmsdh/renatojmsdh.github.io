// Arquivo "src/ClassA.h"
#ifndef _DCC004_CLASS_A
#define _DCC004_CLASS_A
#include <iostream>

class A
{
private:
    int m_n;
public:
	A();
};
#endif
