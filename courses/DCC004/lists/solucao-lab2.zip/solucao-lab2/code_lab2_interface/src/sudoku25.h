#ifndef DCC004_SUDOKU25_H
#define DCC004_SUDOKU25_H

#include "sudoku.h"

class Sudoku25 : public Sudoku
{

public:
Sudoku25();
void read_sudoku() const;
void print_sudoku() const;
void solve_sudoku();

};

#endif
