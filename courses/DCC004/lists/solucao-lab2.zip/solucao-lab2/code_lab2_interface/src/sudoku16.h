#ifndef DCC004_SUDOKU16_H
#define DCC004_SUDOKU16_H

#include "sudoku.h"

class Sudoku16 : public Sudoku
{

public:
Sudoku16();
void read_sudoku() const;
void print_sudoku() const;
void solve_sudoku();

};

#endif
