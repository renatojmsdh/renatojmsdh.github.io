#include "sudoku16.h"

Sudoku16::Sudoku16()
{
read_sudoku();
solve_sudoku();
print_sudoku();
}
void Sudoku16::read_sudoku() const
{
std::cout<<"Li o Sudoku (16 × 16)"<<std::endl;
}
void Sudoku16::print_sudoku() const
{
std::cout<<"Imprimi o Sudoku (16 × 16)"<<std::endl;
}
void Sudoku16::solve_sudoku()
{
std::cout<<"Resolvi o Sudoku (16 × 16)"<<std::endl;
}

