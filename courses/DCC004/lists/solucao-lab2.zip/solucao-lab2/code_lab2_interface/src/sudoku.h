#ifndef DCC004_SUDOKU_H
#define DCC004_SUDOKU_H

#include <iostream>

class Sudoku
{

public:
/*
Sudoku()
{
read_sudoku();
solve_sudoku();
print_sudoku();
}
*/
virtual void read_sudoku() const = 0;
virtual void print_sudoku() const = 0;
virtual void solve_sudoku() = 0;

};

#endif


