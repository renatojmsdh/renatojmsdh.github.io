#include "sudoku9.h"

Sudoku9::Sudoku9()
{
read_sudoku();
solve_sudoku();
print_sudoku();
}

void Sudoku9::read_sudoku() const
{
std::cout<<"Li o Sudoku (9 × 9)"<<std::endl;
}
void Sudoku9::print_sudoku() const
{
std::cout<<"Imprimi o Sudoku (9 × 9)"<<std::endl;
}
void Sudoku9::solve_sudoku()
{
std::cout<<"Resolvi o Sudoku (9 × 9)"<<std::endl;
}

