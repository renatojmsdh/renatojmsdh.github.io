#include "sudoku25.h"

Sudoku25::Sudoku25()
{
read_sudoku();
solve_sudoku();
print_sudoku();
}

void Sudoku25::read_sudoku() const
{
std::cout<<"Li o Sudoku (25 × 25)"<<std::endl;
}
void Sudoku25::print_sudoku() const
{
std::cout<<"Imprimi o Sudoku (25 × 25)"<<std::endl;
}
void Sudoku25::solve_sudoku()
{
std::cout<<"Resolvi o Sudoku (25 × 25)"<<std::endl;
}

