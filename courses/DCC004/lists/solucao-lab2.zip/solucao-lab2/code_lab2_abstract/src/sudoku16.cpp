#include "sudoku16.h"

Sudoku16::Sudoku16() : Sudoku(16)
{
solve_sudoku();
print_sudoku();
}

void Sudoku16::solve_sudoku()
{
std::cout<<"Resolvi o Sudoku ( "<< _size_sudoku << " × " << _size_sudoku << " )"<<std::endl;
}


