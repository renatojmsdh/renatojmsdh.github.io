#include "sudoku25.h"

Sudoku25::Sudoku25() : Sudoku(25)
{
solve_sudoku();
print_sudoku();
}

void Sudoku25::solve_sudoku()
{
std::cout<<"Resolvi o Sudoku ( "<< _size_sudoku << " × " << _size_sudoku << " )"<<std::endl;
}

