#include "sudoku9.h"

Sudoku9::Sudoku9() : Sudoku(9)
{
solve_sudoku();
print_sudoku();
}


void Sudoku9::solve_sudoku()
{
std::cout<<"Resolvi o Sudoku ( "<< _size_sudoku << " × " << _size_sudoku << " )"<<std::endl;
}
