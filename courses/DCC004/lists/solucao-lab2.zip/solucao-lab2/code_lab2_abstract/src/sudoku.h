#ifndef DCC004_SUDOKU_H
#define DCC004_SUDOKU_H

#include <iostream>

class Sudoku
{

protected:
int _size_sudoku;

protected:
Sudoku(const int&);
void read_sudoku() const;
void print_sudoku() const;
virtual void solve_sudoku() = 0;

};

#endif


