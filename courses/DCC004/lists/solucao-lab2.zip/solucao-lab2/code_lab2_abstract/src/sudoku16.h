#ifndef DCC004_SUDOKU16_H
#define DCC004_SUDOKU16_H

#include "sudoku.h"

class Sudoku16 : public Sudoku
{

public:
Sudoku16();
void solve_sudoku();

};

#endif
