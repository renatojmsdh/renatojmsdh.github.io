#ifndef DCC004_SUDOKU9_H
#define DCC004_SUDOKU9_H

#include "sudoku.h"

class Sudoku9 : public Sudoku
{

public:
Sudoku9();
void solve_sudoku();

};

#endif
