#include "sudoku.h"

Sudoku::Sudoku(const int& size){
_size_sudoku = size;
read_sudoku();
//solve_sudoku();
}

void Sudoku::read_sudoku() const
{
std::cout<<"Li o Sudoku ( "<< _size_sudoku << " × " << _size_sudoku << " )"<<std::endl;
}
void Sudoku::print_sudoku() const
{
std::cout<<"Imprimi o Sudoku ( "<< _size_sudoku << " × " << _size_sudoku << " )"<<std::endl;
}





