#include <iostream>
#include <cstdlib>

int main() {
std::string nota = "data/nota-1.png";
std::string textoNota = "data/textoNota-1";
std::string programa = "tesseract " + nota + " " + textoNota + " -l por"; 
const char *comando = programa.c_str();
system(comando);
return 0;
}
